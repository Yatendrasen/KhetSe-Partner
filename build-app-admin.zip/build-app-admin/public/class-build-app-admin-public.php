<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://buildapp.online
 * @since      1.0.0
 *
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/public
 * @author     Abdul Hakeem <info@buildapp.online>
 */
class Build_App_Admin_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Build_App_Admin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Build_App_Admin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/build-app-admin-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Build_App_Admin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Build_App_Admin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/build-app-admin-public.js', array( 'jquery' ), $this->version, false );

	}

    public function admin_options() {

        $data = array();

        $options = get_option('build_app_admin_options');

        if(is_array($options)) {
            $data = array(
                'delivery_boy_role' => $options['delivery_boy_role'],
            );  
        }
        

        $user = wp_get_current_user();

        $customer = new WC_Customer( $user->ID );
        $data['user'] = $this->get_formatted_item_data_customer( $customer );

        $data['vendor_type'] = $this->which_vendor();
        $data['distance'] = (String)$options['delivery_boy_search_distance'];
        $data['vendor_settings'] = get_option('bao_vendor_settings', null);
        $data['delivery_settings'] = get_option('bao_delivery_settings', null);

        $adminUIDs = array();

        $admins = get_users( [ 'role__in' => [ 'administrator' ] ] );
        foreach ( $admins as $user ) {
            $adminUID = get_user_meta( $user->id, 'bao_uid', true );
            if($adminUID) {
                $adminUIDs[] = $adminUID;
            }
        }

        $data['adminUIDs'] = $adminUIDs;

        //$clsCountries = new WC_Countries();

        $data['info'] = array(
            'name' => get_bloginfo('name'),
            'description' => get_bloginfo('description'),
            'email' => get_bloginfo('admin_email'),
            'url' => get_bloginfo('url'),
            'phone' => $options['contact_number'],
            'currency' => get_woocommerce_currency(),
            //'defaultCountry' => $clsCountries->get_base_country(),
            //'baseState' => $clsCountries->get_base_state(),
            'priceDecimal' => wc_get_price_decimals(),
            //'vendorType' => $this->which_vendor(),
            //'is_rtl' => is_rtl(),

        );

        if(isset($_REQUEST['driver_app'])) {
            $data['theme'] = get_option('bao_delivery_boy_theme');
        } else {
            $data['theme'] = get_option('bao_vendor_theme');
        }

        /*$options = get_option( 'sochm_basic_settings' );
        
        $data['closed'] = $options['close_store'] == 'on' ? true : false;*/
        

        $order_statuses = wc_get_order_statuses();

        foreach ($order_statuses as $key => $value) {
            $data['order_statuses'][] = array(
                'key' => str_replace('wc-', '', $key),
                'value' => $value
            );
        }

        $new_order_status = $options['delivery_new_order_status'];

        if(isset($new_order_status)) {
            foreach ($new_order_status as $key => $value) {
                $data['new_order_status'][] = array(
                    'key' => str_replace('wc-', '', $value),
                    'value' => $order_statuses[$value]
                );
            }
        } else {
            $data['new_order_status'][] = array(
                'key' => 'wc-processing',
                'value' => 'Processing'
            );
        }

        wp_send_json($data);

    }

    protected function get_formatted_item_data_customer( $object ) {
        $data        = $object->get_data();
        $format_date = array( 'date_created', 'date_modified' );

        // Format date values.
        foreach ( $format_date as $key ) {
            $datetime              = $data[ $key ];
            $data[ $key ]          = wc_rest_prepare_date_response( $datetime, false );
            $data[ $key . '_gmt' ] = wc_rest_prepare_date_response( $datetime );
        }

        return array(
            'id'                 => $object->get_id(),
            'date_created'       => $data['date_created'],
            'date_created_gmt'   => $data['date_created_gmt'],
            'date_modified'      => $data['date_modified'],
            'date_modified_gmt'  => $data['date_modified_gmt'],
            'email'              => $data['email'],
            'first_name'         => $data['first_name'],
            'last_name'          => $data['last_name'],
            'role'               => $data['role'],
            'username'           => $data['username'],
            'billing'            => $data['billing'],
            'shipping'           => $data['shipping'],
            'is_paying_customer' => $data['is_paying_customer'],
            'orders_count'       => $object->get_order_count(),
            'total_spent'        => $object->get_total_spent(),
            'avatar_url'         => $object->get_avatar_url(),
            'meta_data'          => $data['meta_data'],
            'is_online'          => (bool)get_user_meta($object->get_id(), '_bao_delivery_online', true),
            'notification'       => (bool)get_user_meta($object->get_id(), '_bao_delivery_notification', true),
        );
    }

    public function is_online() {
        $offline = get_user_meta(get_current_user_id(), '_wcfm_store_offline', true);
        if($offline == 'yes') {
            return false;
        } else return true;
    }

    public function admin_login() {

        $creds = array(
            'user_login'    => addslashes(rawurldecode($_REQUEST['username'])),
            'user_password' => addslashes(rawurldecode($_REQUEST['password'])),
            'remember'      => true,
        );

        $user = wp_signon( apply_filters( 'woocommerce_login_credentials', $creds ), is_ssl() );

        if(!is_wp_error( $user )) {
            $customer = new WC_Customer( $user->ID );
            $data = $this->get_formatted_item_data_customer( $customer );
            wp_send_json( $data  );
        } else {
            wp_send_json_error( $user, 400 );
        }

    }

    public function admin_logout() {
        wp_logout();

        wp_send_json(true);
    }

    private function which_vendor() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }
        if(is_plugin_active( 'dokan-lite/dokan.php') || is_plugin_active( 'dokan/dokan.php' )){
            return 'dokan';
        }
        else if(is_plugin_active( 'dc-woocommerce-multi-vendor/dc_product_vendor.php' )){
            return 'wc_marketplace';
        }
        else if(is_plugin_active( 'wc-multivendor-marketplace/wc-multivendor-marketplace.php' )){      
            return 'wcfm';
        } else if(is_plugin_active( 'woocommerce-product-vendors/woocommerce-product-vendors.php' )){      
            return 'product_vendor';
        }
        else return null;
    }

    public function vendor_order_list(){

      $cls = new WC_Product_Vendors_Vendor_Orders_List();

      $cls->prepare_items();

      $commisions = $cls->items;

      $format_decimal    = array( 'discount_total', 'discount_tax', 'shipping_total', 'shipping_tax', 'shipping_total', 'shipping_tax', 'cart_tax', 'total', 'total_tax' );
      $format_date       = array( 'date_created', 'date_modified' );

      $orders = array();
      foreach ($commisions as $key => $item) {
        $quantity       = absint( $item->product_quantity );
        $var_attributes = '';
        $sku            = '';
        $order = wc_get_order( absint( $item->order_id ) );
        $data  = $order->get_data();

        // Format decimal values.
        foreach ( $format_decimal as $key ) {
            $data[ $key ] = wc_format_decimal( $data[ $key ], wc_get_price_decimals() );
        }

        // Format date values.
        foreach ( $format_date as $key ) {
            $datetime              = $data[ $key ];
            $data[ $key ]          = wc_rest_prepare_date_response( $datetime, false );
            $data[ $key . '_gmt' ] = wc_rest_prepare_date_response( $datetime );
        }

        // Format the order status.
        $data['status'] = 'wc-' === substr( $data['status'], 0, 3 ) ? substr( $data['status'], 3 ) : $data['status'];


        // Refunds.
        $data['refunds'] = array();
        foreach ( $order->get_refunds() as $refund ) {
            $data['refunds'][] = array(
                'id'     => $refund->get_id(),
                'reason' => $refund->get_reason() ? $refund->get_reason() : '',
                'total'  => '-' . wc_format_decimal( $refund->get_amount(), wc_get_price_decimals() ),
            );
        }

        if ( ! empty( $item->variation_id ) ) {
            $product = wc_get_product( absint( $item->variation_id ) );
            if ( $metadata = $order->has_meta( $item->order_item_id ) ) {
                foreach ( $metadata as $meta ) {
                    // Skip hidden core fields
                    if ( in_array( $meta['meta_key'], apply_filters( 'wcpv_hidden_order_itemmeta', array(
                        '_qty',
                        '_tax_class',
                        '_product_id',
                        '_variation_id',
                        '_line_subtotal',
                        '_line_subtotal_tax',
                        '_line_total',
                        '_line_tax',
                        '_fulfillment_status',
                        '_commission_status',
                        'method_id',
                        'cost',
                    ) ) ) ) {
                        continue;
                    }

                    // Skip serialised meta
                    if ( is_serialized( $meta['meta_value'] ) ) {
                        continue;
                    }

                    // Get attribute data
                    if ( taxonomy_exists( wc_sanitize_taxonomy_name( $meta['meta_key'] ) ) ) {
                        $term               = get_term_by( 'slug', $meta['meta_value'], wc_sanitize_taxonomy_name( $meta['meta_key'] ) );
                        $meta['meta_key']   = wc_attribute_label( wc_sanitize_taxonomy_name( $meta['meta_key'] ) );
                        $meta['meta_value'] = isset( $term->name ) ? $term->name : $meta['meta_value'];
                    } else {
                        $meta['meta_key']   = wc_attribute_label( $meta['meta_key'], $product );
                    }

                    $var_attributes .= sprintf( __( '<br /><small>( %1$s: %2$s )</small>', 'woocommerce-product-vendors' ), wp_kses_post( rawurldecode( $meta['meta_key'] ) ), wp_kses_post( $meta['meta_value'] ) );
                }
            }
        } else {
            $product = wc_get_product( absint( $item->product_id ) );

        }

        $orders[] = array(
            'id'                   => $order->get_id(),
            'parent_id'            => $data['parent_id'],
            'number'               => $data['number'],
            'order_key'            => $data['order_key'],
            'created_via'          => $data['created_via'],
            'version'              => $data['version'],
            'status'               => WC_Product_Vendors_Utils::format_order_status( $order->get_status() ),
            'currency'             => $data['currency'],
            'date_created'         => WC_Product_Vendors_Utils::format_date( sanitize_text_field( $item->order_date ), $timezone ),
            'discount_total'       => $data['discount_total'],
            'discount_tax'         => $data['discount_tax'],
            'shipping_total'       => $data['shipping_total'],
            'shipping_tax'         => $data['shipping_tax'],
            'cart_tax'             => $data['cart_tax'],
            'total'                => $data['total'],
            'total_tax'            => $data['total_tax'],
            'prices_include_tax'   => $data['prices_include_tax'],
            'customer_id'          => $data['customer_id'],
            'customer_ip_address'  => $data['customer_ip_address'],
            'customer_user_agent'  => $data['customer_user_agent'],
            'customer_note'        => $data['customer_note'],
            'billing'              => $data['billing'],
            'shipping'             => $data['shipping'],
            'payment_method'       => $data['payment_method'],
            'payment_method_title' => $data['payment_method_title'],
            'transaction_id'       => $data['transaction_id'],
            'cart_hash'            => $data['cart_hash'],
            'meta_data'            => $data['meta_data'],
            'product_id'         => $item->product_id,
            'quantity'             => absint( $item->product_quantity ),
            'product_name'         => $item->product_name,
            'var_attributes'       => $var_attributes,
            'sku'                   => $product->get_sku(),
            'total_commission_amount' => $item->total_commission_amount,
            'fulfillment_status' => WC_Product_Vendors_Utils::get_fulfillment_status( $item->order_item_id ),
            'paid_date' => WC_Product_Vendors_Utils::format_date( sanitize_text_field( $item->paid_date ), '' ),
            'commission_status' => $item->commission_status,
            'order_item_id' =>$item->order_item_id,
        );
      }

      wp_send_json( $orders );
      
    }

    public function set_fulfill_status() {

        $order_item_id = $_REQUEST['order_item_id'];

        $status = $_REQUEST['status']; 

        global $wpdb;

        $sql = "UPDATE {$wpdb->prefix}woocommerce_order_itemmeta";
        $sql .= ' SET `meta_value` = %s';
        $sql .= ' WHERE `order_item_id` = %d AND `meta_key` = %s';

        $val = $wpdb->get_var( $wpdb->prepare( $sql, $status, $order_item_id, '_fulfillment_status' ) );

        wp_send_json( $status );
    }

    public function google_login() {
        
        if (isset($_POST['email'])) {

            $email = $_POST['email'];

            $email_exists = email_exists($email);

            if ($email_exists) {
                $user = get_user_by('email', $email);
                $user_id = $user->ID;
                $expiration = time() + apply_filters('auth_cookie_expiration', 91209600, $user_id, true);
                $cookie = wp_generate_auth_cookie($user_id, $expiration, 'logged_in');
                wp_set_auth_cookie($user_id, true);
                wp_send_json($user);
            } else {
                $data = array(
                    'code' => 'empty_username',
                    'message' => 'Unknown email address. Check again or try your username.',
                );
                wp_send_json_error($data, 400);
            } 
        } else {
            $data = array(
                'code' => 'empty_username',
                'message' => 'Unknown email address. Check again or try your username.',
            );
            wp_send_json_error($data, 400);
        }
    }

    public function update_location() {
        $user_id = get_current_user_id();
        $longitude = $_REQUEST['longitude'];
        $latitude = $_REQUEST['latitude'];
        update_user_meta( $user_id, 'longitude', $longitude );
        update_user_meta( $user_id, 'latitude', $latitude );
        wp_send_json(true);
    }

    public function get_delivery_info() {
        
        $order_id = $_REQUEST['order_id'];

        global $wpdb;
        
        $delivery_orders = $wpdb->get_results(  $wpdb->prepare( "SELECT ID from {$wpdb->prefix}wcfm_delivery_orders WHERE order_id = %d", $order_id ) );

        wp_send_json(
            array(
                'delivery_id' => $delivery_orders
            )
        );
    }

    public function get_brands() {

      $brands_data = array();

      $brands = get_terms( 'pwb-brand',array( 'hide_empty' => false ) );
      foreach( $brands as $brand ){

        $current_brand = array(
          'slug'        =>  $brand->slug,
          'name'        =>  $brand->name,
          'banner_link' =>  get_term_meta( $brand->term_id, 'pwb_brand_banner_link', true ),
          'desc'        =>  htmlentities( $brand->description )
        );

        $image = get_term_meta( $brand->term_id, 'pwb_brand_image', true );
        $image = wp_get_attachment_image_src( $image, 'full' );
        if( $image ) $current_brand['image'] = $image[0];

        $banner = get_term_meta( $brand->term_id, 'pwb_brand_banner', true );
        $banner = wp_get_attachment_image_src( $banner, 'full' );
        if( $banner ) $current_brand['banner'] = $banner[0];

        $brands_data[] = $current_brand;

      }

      wp_send_json( $brands_data );

    }

    public function uploadimage() {

          if ( ! function_exists( 'wp_handle_upload' ) ) {
              require_once( ABSPATH . 'wp-admin/includes/file.php' );
          }

          $uploadedfile = $_FILES['file'];

          $upload_overrides = array( 'test_form' => false );

          $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );

          if ( $movefile && ! isset( $movefile['error'] ) ) {
             // echo "File is valid, and was successfully uploaded.\n";
              wp_send_json( $movefile );
          } else {
              /**
               * Error generated by _wp_handle_upload()
               * @see _wp_handle_upload() in wp-admin/includes/file.php
               */
              wp_send_json( $movefile );      }

             // wp_send_json( $data );

            die();
    }

    public function uploadimages() {


        $img = $_POST['image'];
        $img = str_replace('data:image/png;base64,', '', $img);
        $img = str_replace(' ', '+', $img);

        $decoded = base64_decode($img);

        $upload_dir = wp_upload_dir();

        // @new
        $upload_path = str_replace( '/', DIRECTORY_SEPARATOR, $upload_dir['path'] ) . DIRECTORY_SEPARATOR;

        $decoded = $image;
        $filename = 'my-base64-image.png';

        $hashed_filename = md5( $filename . microtime() ) . '_' . $filename;

        // @new
        $image_upload = file_put_contents( $upload_path . $hashed_filename, $decoded );

        //HANDLE UPLOADED FILE
        if( !function_exists( 'wp_handle_sideload' ) ) {
          require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }

        // Without that I'm getting a debug error!?
        if( !function_exists( 'wp_get_current_user' ) ) {
          require_once( ABSPATH . 'wp-includes/pluggable.php' );
        }

        // @new
        $file             = array();
        $file['error']    = '';
        $file['tmp_name'] = $upload_path . $hashed_filename;
        $file['name']     = $hashed_filename;
        $file['type']     = 'image/png';
        $file['size']     = filesize( $upload_path . $hashed_filename );

        // upload file to server
        // @new use $file instead of $image_upload
        $file_return = wp_handle_sideload( $file, array( 'test_form' => false ) );

        $filename = $file_return['file'];

        $filepath = $wp_upload_dir['url'] . '/' . basename($filename);

        wp_send_json( $filepath );

    }

    public function bao_update_user_meta() {
        
        $data = json_decode(file_get_contents("php://input"));
        
        $user_id = get_current_user_id();
        if($user_id){
            foreach($data as $k => $v) {
                //$value = sanitize_text_field($v);
                update_user_meta( $user_id, $k, $v );
            }
            wp_send_json(true);
        } else wp_send_json(false);
    }

    public function fcm_details() {
        if(isset($_REQUEST['token'])) {

            $token = sanitize_text_field($_REQUEST['token']);
        
            $options = get_option('build_app_admin_options');

            $apikey = $options['firebase_server_key'];

            $fcm_remote_url = "https://iid.googleapis.com/iid/info/" . $token . "?details=true";
             
            $args = array(
              'timeout' => '5',
              'redirection' => '5',
              'httpversion' => '1.0',
              'blocking' => true,
              'headers' => array(),
              'cookies' => array(),
              'headers' => array(
                'Content-type' => 'application/json',
                'Authorization' => 'key=' . $apikey
              )
            );

            $response = wp_remote_get( $fcm_remote_url, $args );


            if ( is_array( $response ) && ! is_wp_error( $response ) ) {
                $data = (array)json_decode($response['body']);
                $data['topics'] = array();
                if(isset($data['rel'])) {
                    foreach ($data['rel']->topics as $key => $value) {
                        $data['topics'][] = $key;
                    }
                }
                wp_send_json($data);// use the content
            }

            wp_send_json_error($response['body']);

        }
    }

    

}
