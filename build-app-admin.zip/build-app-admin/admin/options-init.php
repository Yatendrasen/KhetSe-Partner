<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "build_app_admin_options";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

       // global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => 'Build app admin options',
        // Name that appears at the top of your panel
        'display_version'      => '0.0.1',
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Build app admin', 'build-app-admin' ),
        'page_title'           => __( 'Build app admin', 'build-app-admin' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'bar'            => false,
        // Show the panel pages on the admin bar
        'bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.
        'show_options_object' => false,

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
      
    );



    Redux::setArgs( $opt_name, $args );
   

    Redux::setSection( $opt_name, array(
        'title' => __( 'Admin App', 'build-app-admin' ),
        'id'    => 'mstoreapp_flutter_admin_app',
        'desc'  => __( 'Admin app settings', 'mstoreapp-admin' ),
        'icon'  => 'el el-website'
    ) );

    /*Redux::setSection( $opt_name, array(
        'title'      => __( 'One Signal', 'mstoreapp-admin' ),
        'id'         => 'apps_one_signal_settings',
        'subsection' => true,
        'icon'  => 'el el-podcast',
        'fields'     => array(
            array(
                'id'       => 'onesignal_app_id',
                'type'     => 'hidden',
                //'placeholder' => 'af9110f9-abca-4e0a-b482-ae944342da11',
                //'title'    => 'OneSignal app id',
                //'subtitle' => 'Enter OneSignal app id',
                'default'  => 'af9110f9-abca-4e0a-b482-ae944342da11',
            ),
            array(
                'id'       => 'onesignal_app_rest_api_key',
                'type'     => 'hidden',
                //'placeholder' => 'MTdiYzJkOTEtYzEwNC00NjQ4LTkxMTEtOTlmMmRjMTA5MDI5',
                //'title'    => 'OneSignal rest api keys',
                //'subtitle' => 'This will allow you to sent notification from WordPress admin panel',
                'default'  => 'MTdiYzJkOTEtYzEwNC00NjQ4LTkxMTEtOTlmMmRjMTA5MDI5',
            ),
            array(
                'id'       => 'firebase_sender_id',
                'type'     => 'hidden',
                //'placeholder' => '575406529046',
                //'title'    => 'Firebase sender id',
                //'subtitle' => 'Enter Firebase sender id',
                'default'  => '575406529046',
            ),
        )
    ) );*/

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Admin Push Settings', 'mstoreapp-admin' ),
        'id'         => 'apps_admin_push_settings',
        'subsection' => true,
        'icon'  => 'el el-cog',
        'fields'     => array(
            /*array(
                'id'       => 'onesignal_app_id',
                'type'     => 'text',
                'placeholder' => '18a592a9-6949-4f32-8101-6910f5a2614a',
                'title'    => 'OneSignal app id',
                'subtitle' => 'Enter OneSignal app id',
                'default'  => '18a592a9-6949-4f32-8101-6910f5a2614a',
            ),
            array(
                'id'       => 'onesignal_app_rest_api_key',
                'type'     => 'text',
                'placeholder' => 'YTU4MzAwMWUtN2JkYy00ZDJkLTgwNWQtNGVlNjgyNzgxM2M5',
                'title'    => 'OneSignal rest api keys',
                'subtitle' => 'This will allow you to sent notification from WordPress admin panel',
                'default'  => 'YTU4MzAwMWUtN2JkYy00ZDJkLTgwNWQtNGVlNjgyNzgxM2M5',
            ),*/
            array(
                'id'       => 'firebase_web_app_api_key',
                'type'     => 'text',
                'title'    => 'Firebase web app api key',
                'subtitle' => 'Enter Firebase web app api key',
                'placeholder' => 'AIza3sfTgf5MP7dSe_UiZXYhDtsOVPpQnxEHTc',
                'default'  => '',
            ),
            array(
                'id'       => 'firebase_server_key',
                'type'     => 'text',
                'title'    => 'Firebase Server Key',
                'subtitle' => 'Enter Firebase Server Key',
                'placeholder' => 'AAAAu8sIWr0:APA91bG15aYz9iKHcsOskRHjduIjslKoDgErWcrNWVBUoOBFhq9QGsPW4m8LDN5EHr16cu_hxTewzkCJcmmSzfJg3EK4MclC85xe3HuTyDjnOeXNdjenHNIuA',
                'default'  => '',
            ),
            array(
                'id'       => 'firebase_sender_id',
                'type'     => 'text',
                'placeholder' => '126170115534',
                'title'    => 'Firebase sender id',
                'subtitle' => 'Enter Firebase sender id',
                'default'  => '126170115534',
            ),
            array(
                'id'       => 'push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'All Notifications', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable all notifications for admin apps', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'new_order_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new order', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'low_stock_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Low Stock', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for low stock', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'new_customer_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New Customer', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new customer', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'new_review_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New Product Review', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new product reviews', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            /*array(
                'id'       => 'new_product_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New Product', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new product', 'mstoreapp-admin' ),
                'default'  => true,
            )*/
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Admin Message', 'mstoreapp-admin' ),
        'id'         => 'apps_admin_push_text',
        'subsection' => true,
        'icon'  => 'el el-envelope',
        'fields'     => array(
            array(
                'id'       => 'new_order_admin_title',
                'type'     => 'text',
                'title'    => 'Order Title',
                'subtitle' => 'New order push notification title. #id will be replaced by order id',
                'validate' => 'text',
                'default'  => '#id New Order',
            ),
            array(
                'id'       => 'new_order_admin_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Order Message',
                'subtitle' => 'New order push notification message. #id will be replaced by order id. #pm replaced by payment method',
                'validate' => 'text',
                'default'  => 'You have received a new order of Total #total, Order id #id, Payment method #pm',
            ),
            array(
                'id'       => 'low_stock_admin_title',
                'type'     => 'text',
                'title'    => 'Low Stock Title',
                'subtitle' => 'Low stock push notification message. #id will be replaced by customer id, #name will be replaced by customer name',
                'validate' => 'text',
                'default'  => '#id Low Stock',
            ),
            array(
                'id'       => 'low_stock_admin_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Low Stock Message',
                'subtitle' => 'Low stock push notification message. #id by product id, #name by product name, #sku by product SKU, #qty by product quantity will be replaced',
                'validate' => 'text',
                'default'  => '#name has got stock level low, id: #id, name: #name, sku: #sku and current quantity: #qty',
            ),
            array(
                'id'       => 'new_customer_admin_title',
                'type'     => 'text',
                'title'    => 'New Customer Title',
                'subtitle' => 'Low stock push notification title. #id will be replaced by customer id',
                'validate' => 'text',
                'default'  => '#id New Customer',
            ),
            array(
                'id'       => 'new_customer_admin_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'New Customer Message',
                'subtitle' => 'New Customer push notification message. #id will be replaced by customer id, #name will be replaced by customer name',
                'validate' => 'text',
                'default'  => 'You have a new customer #name',
            ),
            array(
                'id'       => 'new_review_admin_title',
                'type'     => 'text',
                'title'    => 'New Product Review Title',
                'subtitle' => 'New Product Review push notification title. #name will be replaced by product name, #rating will be replaced by rating, #review will be replaced by Reviews, #author will be replaced by author',
                'validate' => 'text',
                'default'  => '#rating #review by #author',
            ),
            array(
                'id'       => 'new_review_admin_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'New Product Review Message',
                'subtitle' => 'New Product Review push notification message. #name will be replaced by product name, #rating will be replaced by rating, #review will be replaced by Reviews, #author will be replaced by author',
                'validate' => 'text',
                'default'  => 'You have a new Product Review for product #name',
            ),
        )
    ) );


    //Vendor app settings
    Redux::setSection( $opt_name, array(
        'title' => __( 'Vendor App', 'mstoreapp-admin' ),
        'id'    => 'mstoreapp_vendor_app',
        'desc'  => __( 'Vendor app settings', 'mstoreapp-admin' ),
        'icon'  => 'el el-website'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Firebase', 'mstoreapp-admin' ),
        'id'         => 'vendor_apps_one_signal_settings',
        'subsection' => true,
        'icon'  => 'el el-podcast',
        'fields'     => array(
            /*array(
                'id'       => 'vendor_apps_onesignal_app_id',
                'type'     => 'text',
                'placeholder' => 'af9110f9-abca-4e0a-b482-ae944342da11',
                'title'    => 'OneSignal app id',
                'subtitle' => 'Enter OneSignal app id',
                'default'  => 'af9110f9-abca-4e0a-b482-ae944342da11',
            ),
            array(
                'id'       => 'vendor_apps_onesignal_app_rest_api_key',
                'type'     => 'text',
                'placeholder' => 'MTdiYzJkOTEtYzEwNC00NjQ4LTkxMTEtOTlmMmRjMTA5MDI5',
                'title'    => 'OneSignal rest api keys',
                'subtitle' => 'This will allow you to sent notification from WordPress admin panel',
                'default'  => '',
            ),*/
            array(
                'id'       => 'vendor_apps_firebase_web_app_api_key',
                'type'     => 'text',
                'title'    => 'Firebase web app api key',
                'subtitle' => 'Enter Firebase web app api key',
                'placeholder' => 'AIza3sfTgf5MP7dSe_UiZXYhDtsOVPpQnxEHTc',
                'default'  => '',
            ),
            array(
                'id'       => 'vendor_apps_firebase_server_key',
                'type'     => 'text',
                'title'    => 'Firebase Server Key',
                'subtitle' => 'Enter Firebase Server Key',
                'placeholder' => 'AAAAu8sIWr0:APA91bG15aYz9iKHcsOskRHjduIjslKoDgErWcrNWVBUoOBFhq9QGsPW4m8LDN5EHr16cu_hxTewzkCJcmmSzfJg3EK4MclC85xe3HuTyDjnOeXNdjenHNIuA',
                'default'  => '',
            ),
            array(
                'id'       => 'vendor_apps_firebase_sender_id',
                'type'     => 'text',
                'placeholder' => '575406529046',
                'title'    => 'Firebase sender id',
                'subtitle' => 'Enter Firebase sender id',
                'default'  => '575406529046',
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Vendor Push Settings', 'mstoreapp-admin' ),
        'id'         => 'apps_vendor_push_settings',
        'subsection' => true,
        'icon'  => 'el el-cog',
        'fields'     => array(
            array(
                'id'       => 'vendor_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'All Notifications', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable all notifications for admin apps', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'vendor_new_order_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new order', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'vendors_for_new_order_push',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'New order notification roles', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select user roles to get notification for new order', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendor_low_stock_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Low Stock', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for low stock', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'vendors_for_low_stock_push',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Low stock notification roles', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select user roles to get notification for low stock', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendor_new_customer_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New Customer', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new customer', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'vendors_for_new_customer_push',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'New Customer notification roles', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select user roles to get notification for new customer', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendor_new_review_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New Product Review', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new product reviews for vendor', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'vendors_new_review_push',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Product Review notification roles', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select user roles to get notification for new product reviews', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Vendor Message', 'mstoreapp-admin' ),
        'id'         => 'apps_vendor_push_text',
        'subsection' => true,
        'icon'  => 'el el-envelope',
        'fields'     => array(
            array(
                'id'       => 'new_order_vendor_title',
                'type'     => 'text',
                'title'    => 'Order Title',
                'subtitle' => 'New order push notification title. #id will be replaced by order id',
                'validate' => 'text',
                'default'  => '#id New order',
            ),
            array(
                'id'       => 'new_order_vendors_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Order Message',
                'subtitle' => 'New order push notification message. #id will be replaced by order id. #pm replaced by payment method',
                'validate' => 'text',
                'default'  => 'You have received a new order of Total #total, Order id #id, Payment method #pm',
            ),
            array(
                'id'       => 'low_stock_vendor_title',
                'type'     => 'text',
                'title'    => 'Low Stock Title',
                'subtitle' => 'Low stock push notification title. %id will be replaced by product id',
                'validate' => 'text',
                'default'  => '#id Low Stock',
            ),
            array(
                'id'       => 'low_stock_vendors_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Low Stock Message',
                'subtitle' => 'Low stock push notification message. #id by product id, #name by product name, #sku by product SKU, #qty by product quantity will be replaced',
                'validate' => 'text',
                'default'  => '#name has got stock level low, id: #id, name: #name, sku: #sku and current quantity: #qty',
            ),
            array(
                'id'       => 'new_customer_vendor_title',
                'type'     => 'text',
                'title'    => 'New Customer Title',
                'subtitle' => 'Low stock push notification title. #id will be replaced by customer id',
                'validate' => 'text',
                'default'  => '#id New Customer',
            ),
            array(
                'id'       => 'new_customer_vendors_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'New Customer Message',
                'subtitle' => 'New Customer push notification message. #id will be replaced by customer id, #name will be replaced by customer name',
                'validate' => 'text',
                'default'  => 'You have a new customer #name',
            ),
            array(
                'id'       => 'new_review_vendor_title',
                'type'     => 'text',
                'title'    => 'New Product Review Title',
                'subtitle' => 'New Product Review push notification title. #name will be replaced by product name, #rating will be replaced by rating, #review will be replaced by Reviews, #author will be replaced by author',
                'validate' => 'text',
                'default'  => '#rating #review by #author',
            ),
            array(
                'id'       => 'new_review_vendors_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'New Product Review Message',
                'subtitle' => 'New Product Review push notification message. #name will be replaced by product name, #rating will be replaced by rating, #review will be replaced by Reviews, #author will be replaced by author',
                'validate' => 'text',
                'default'  => 'You have a new Product Review for product #name',
            ),
        )
    ) );

    /*Redux::setSection( $opt_name, array(
        'title'      => __( 'Vendor Permissions', 'mstoreapp-admin' ),
        'id'         => 'apps_vendor_permissions',
        'subsection' => true,
        'icon'  => 'el el-key',
        'fields'     => array(
            array(
                'id'       => 'vendors_role_to_access_app',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access app', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the app', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendor-read-permission',
                'type'     => 'section',
                'title'    => __( 'Read Only Permission', 'mstoreapp-admin' ),
                'subtitle' => __( 'With this roles vendor can get read permissions. These users can view orders, products, customer etc', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),
            array(
                'id'       => 'vendors_role_to_read_orders',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access orders', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the view orders', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_read_products',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access products', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the view products', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_read_customers',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access customers', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the view customers', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_read_profile',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access profile', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the view profile', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_read_order_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'View order fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order fields vendor can view', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order fields vendor can view.', 'mstoreapp-admin' ),
                'options'  => array(
                    'number' => 'Order Number',
                    'status' => 'Order Status',
                    'date_created' => 'Order Date',
                    'line_items' => 'Line Items',
                    'billing' => 'Billing Address',
                    'shipping' => 'Shipping Address',
                    'payment_method' => 'Payment Method',
                    'shipping_lines' => 'Shipping Method',
                    'totals' => 'Totals'),
                'default'  => array( 'number', 'status', 'date_created', 'line_items', 'billing', 'shipping', 'payment_method', 'shipping_lines', 'totals' )
            ),
            array(
                'id'       => 'vendors_read_product_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'View product fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Product fields vendor can view', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control product fields vendor can view.', 'mstoreapp-admin' ),
                'options'  => array(
                    'type' => 'Type',
                    'status' => 'Status',
                    'featured' => 'Featured',
                    'catalog_visibility' => 'Catalog Visibility',
                    'description' => 'Description',
                    'short_description' => 'Short Description',
                    'sku' => 'SKU',
                    'price' => 'Price',
                    'on_sale' => 'On Sale',
                    'purchasable' => 'Purchasable',
                    'total_sales    ' => 'Total Sales',
                    'manage_stock' => 'Manage Stock',
                    'stock_quantity' => 'Stock Quantity',
                    'stock_status' => 'Stock Status',
                    'weight' => 'Weight',
                    'rating_count    ' => 'Rating Count',
                    'related_ids' => 'Related Products',
                    'variations' => 'Variations',
                    'purchase_note' => 'Purchase Note',
                    'categories    ' => 'Categories',
                    'tags' => 'Tags',
                    'images' => 'Images',
                    'attributes' => 'Attributes',
                    'purchasable' => 'Purchasable',
                    'sold_individually' => 'Sold Individually',
                    'shipping_required' => 'Shipping Required',
                    'date_on_sale_from' => 'Date on sale'),
                'default'  => array( 'type', 'status', 'featured', 'catalog_visibility', 'description', 'short_description', 'sku', 'price', 'on_sale', 'purchasable', 'total_sales', 'manage_stock', 'stock_quantity', 'stock_status', 'weight', 'rating_count', 'related_ids', 'variations', 'purchase_note', 'categories', 'tags', 'images', 'attributes', 'date_on_sale_from', )
            ),

            array(
                'id'       => 'vendors_filter_order_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Filter order fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order fields vendor can filter', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow you to control order fields vendor can filter.', 'mstoreapp-admin' ),
                'options'  => array(
                    'after' => 'Date After',
                    'before' => 'Date Before',
                    'status' => 'Status',
                    'order' => 'Order',),
                'default'  => array( 'after', 'before', 'status', 'order' )
            ),

            array(
                'id'       => 'vendors_filter_product_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Filter product fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Product fields vendor can filter', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow you to control product fields vendor can filter.', 'mstoreapp-admin' ),
                'options'  => array(
                    'sku' => 'SKU',
                    'after' => 'Date After',
                    'before' => 'Date Before',
                    'stock_status' => 'Stock Status',
                    'status' => 'Status',
                    'type' => 'Type',
                    'order' => 'Order',
                    'on_sale' => 'On Sale',
                    'featured' => 'Featured'),
                'default'  => array( 'sku', 'after', 'before', 'stock_status', 'status', 'type', 'order', 'one_sale', 'featured' )
            ),

            array(
                'id'       => 'vendor-write-permission',
                'type'     => 'section',
                'title'    => __( 'Read/Write Permission', 'mstoreapp-admin' ),
                'subtitle' => __( 'With this roles vendor can get both read and write permissions. These users can edit and create orders, products, customers etc', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),
            array(
                'id'       => 'vendors_role_to_write_orders',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to write orders', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the write orders', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_write_products',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to write products', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the write products', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_write_customers',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to write customers', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the write customers', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_role_to_write_profile',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to write profile', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select venor roles to get access to the write profile', 'mstoreapp-admin' ),
                'default'  => array( 'vendor', 'shop_manager', 'wcfm_vendor' )
            ),
            array(
                'id'       => 'vendors_write_order_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Write order fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order fields vendor can edit', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order fields vendor can edit.', 'mstoreapp-admin' ),
                'options'  => array(
                    'status' => 'Order Status',
                    'line_items' => 'Line Items',
                    'billing' => 'Billing Address',
                    'shipping' => 'Shipping Address',
                    'payment_method' => 'Payment Method',
                    'shipping_lines' => 'Shipping Method'),
                'default'  => array( 'status', 'line_items', 'billing', 'shipping', 'payment_method', 'shipping_lines' )
            ),
            array(
                'id'       => 'vendors_write_order_status',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Change order status', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order Status vendor can change', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order status vendor can change.', 'mstoreapp-admin' ),
                'options'  => array(
                    'pending' => 'Pending',
                    'processing' => 'Processing',
                    'on-hold' => 'On Hold',
                    'completed' => 'Completed',
                    'ready-delivery' => 'Ready For Delivery',
                    'cancelled' => 'Cancelled',
                    'refunded' => 'Refunded',
                    'failed' => 'Failed',
                    'trash' => 'Trash'),
                'default'  => array( 'pending', 'processing', 'on-hold', 'completed' )
            ),
            array(
                'id'       => 'vendors_write_product_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Write product fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Product fields vendor can edit', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control product fields vendor can edit.', 'mstoreapp-admin' ),
                'options'  => array(
                    'type' => 'Type',
                    'status' => 'Status',
                    'featured' => 'Featured',
                    'catalog_visibility' => 'Catalog Visibility',
                    'description' => 'Description',
                    'short_description' => 'Short Description',
                    'sku' => 'SKU',
                    'price' => 'Price',
                    'on_sale' => 'On Sale',
                    'purchasable' => 'Purchasable',
                    'total_sales    ' => 'Total Sales',
                    'manage_stock' => 'Manage Stock',
                    'stock_quantity' => 'Stock Quantity',
                    'stock_status' => 'Stock Status',
                    'weight' => 'Weight',
                    'rating_count    ' => 'Rating Count',
                    'related_ids' => 'Related Products',
                    'variations' => 'Variations',
                    'purchase_note' => 'Purchase Note',
                    'categories    ' => 'Categories',
                    'tags' => 'Tags',
                    'images' => 'Images',
                    'attributes' => 'Attributes',
                    'purchasable' => 'Purchasable',
                    'sold_individually' => 'Sold Individually',
                    'shipping_required' => 'Shipping Required',
                    'date_on_sale_from' => 'Date on sale'),
                'default'  => array( 'type', 'status', 'featured', 'catalog_visibility', 'description', 'short_description', 'sku', 'price', 'on_sale', 'purchasable', 'total_sales', 'manage_stock', 'stock_quantity', 'stock_status', 'weight', 'rating_count', 'related_ids', 'variations', 'purchase_note', 'categories', 'tags', 'images', 'attributes', 'date_on_sale_from', )
            ),

            array(
                'id'       => 'vendors_mobile_options',
                'type'     => 'section',
                'title'    => __( 'Mobile Options', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable or disable options for vendor in the mobile app', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),

            array(
                'id'       => 'vendors_mobile_order_options',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Order options', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Oprions available for order', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow you to control order options in mobile app.', 'mstoreapp-admin' ),
                'options'  => array(
                    'edit_order' => 'Edit Order',
                    'view_order' => 'View Order Detail',
                    'delete_order' => 'Delete Order',
                    'add_order' => 'Add Order',
                    'filter_order' => 'Filter Order',
                    'order_note' => 'Order Note',
                    'driver_location' => 'Driver Location',
                    'customer_location' => 'Customer Location',
                    'pickup_location' => 'Pickup Location',
                    'route' => 'Route',
                    'assign_delivery_boy' => 'Assign Delivery Boy',),
                'default'  => array( 'edit_order', 'view_order', 'delete_order', 'add_order', 'filter_order', 'order_note', 'driver_location', 'customer_location', 'pickup_location', 'route', 'assign_delivery_boy' )
            ),

            array(
                'id'       => 'vendors_mobile_product_options',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Product options', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Oprions available for product', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow you to control product options in mobile app.', 'mstoreapp-admin' ),
                'options'  => array(
                    'edit_product' => 'Edit Product',
                    'view_product' => 'View Product Detail',
                    'delete_product' => 'Delete Product',
                    'add_product' => 'Add Product',
                    'filter_product' => 'Filter Product'),
                'default'  => array( 'edit_product', 'view_product', 'delete_product', 'add_product', 'filter_product' )
            ),
        )
    ) );*/

    

    //Delivery Boy
    Redux::setSection( $opt_name, array(
        'title' => __( 'Delivery Boy', 'mstoreapp-admin' ),
        'id'    => 'mstoreapp_delivery_boy',
        'desc'  => __( 'Delivery boy settings', 'mstoreapp-admin' ),
        'icon'  => 'el el-website'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Settings', 'mstoreapp-admin' ),
        'id'         => 'delivery_boy_settings',
        'subsection' => true,
        'icon'  => 'el el-key',
        'fields'     => array(
            array(
                'id'       => 'delivery_boy_role',
                'type'     => 'select',
                'multi'    => false,
                'data'     => 'roles',
                'title'    => __( 'Select delivery boy user role', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select delivery user role to get access to the app', 'mstoreapp-admin' ),
                'desc'     => __( 'Selected user role will allow access the app and allow you to assign orders to delivery boy', 'mstoreapp-admin' ),
                'default'  => 'delivery_boy'
            ),
            array(
                'id'       => 'delivery_enable_geo_location',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Enable Geo Location for Delivery Boy', 'mstoreapp-admin' ),
                'subtitle' => __( 'Enabling this to delivery boy to get order from  from near by vendors only', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'delivery_boy_search_distance',
                'type'     => 'text',
                'title'    => __( 'Delivery boy default distance', 'mstoreapp-admin' ),
                'subtitle' => __( 'Set distance for which delivery boy is can be searched', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to search delievry boy in given distance area to send push notification to delivery boy.', 'mstoreapp-admin' ),
                'validate' => 'numeric',
                'default'  => 10
            ),
            array(
                'id'       => 'delivery_boy_accept_order_count',
                'type'     => 'text',
                'title'    => __( 'No of Orders delivery accept', 'mstoreapp-admin' ),
                'subtitle' => __( 'No of orders a delivery boy can accept', 'mstoreapp-admin' ),
                'desc'     => __( 'No of orders a delivery boy can accept at a time.', 'mstoreapp-admin' ),
                'validate' => 'numeric',
                'default'  => 10
            ),
            array(
                'id'       => 'delivery_new_order_status',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'New order status', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order Status delivery boy can accept', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order status delivery boy can accept.', 'mstoreapp-admin' ),
                'options'  => array(
                    'wc-wc-pending' => 'Pending',
                    'wc-processing' => 'Processing',
                    'wc-on-hold' => 'On Hold',
                    'wc-completed' => 'Completed',
                    'wc-ready-delivery' => 'Ready For Delivery',
                    'wc-cancelled' => 'Cancelled',
                    'wc-refunded' => 'Refunded',
                    'wc-failed' => 'Failed',
                    'wc-trash' => 'Trash'),
                'default'  => array( 'wc-processing' )
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Firebase', 'mstoreapp-admin' ),
        'id'         => 'delivery_boy_one_signal_settings',
        'subsection' => true,
        'icon'  => 'el el-podcast',
        'fields'     => array(
            /*array(
                'id'       => 'delivery_boy_apps_onesignal_app_id',
                'type'     => 'text',
                'placeholder' => 'af9110f9-abca-4e0a-b482-ae944342da11',
                'title'    => 'OneSignal app id',
                'subtitle' => 'Enter OneSignal app id',
                'default'  => 'af9110f9-abca-4e0a-b482-ae944342da11',
            ),
            array(
                'id'       => 'delivery_boy_apps_onesignal_app_rest_api_key',
                'type'     => 'text',
                'placeholder' => 'MTdiYzJkOTEtYzEwNC00NjQ4LTkxMTEtOTlmMmRjMTA5MDI5',
                'title'    => 'OneSignal rest api keys',
                'subtitle' => 'This will allow you to sent notification to delivery boy app',
                'default'  => '',
            ),*/
            array(
                'id'       => 'delivery_boy_vendor_apps_firebase_web_app_api_key',
                'type'     => 'text',
                'title'    => 'Firebase web app api key',
                'subtitle' => 'Enter Firebase web app api key',
                'placeholder' => 'AIza3sfTgf5MP7dSe_UiZXYhDtsOVPpQnxEHTc',
                'default'  => '',
            ),
            array(
                'id'       => 'delivery_boy_vendor_apps_firebase_server_key',
                'type'     => 'text',
                'title'    => 'Firebase Server Key',
                'subtitle' => 'Enter Firebase Server Key',
                'placeholder' => 'AAAAu8sIWr0:APA91bG15aYz9iKHcsOskRHjduIjslKoDgErWcrNWVBUoOBFhq9QGsPW4m8LDN5EHr16cu_hxTewzkCJcmmSzfJg3EK4MclC85xe3HuTyDjnOeXNdjenHNIuA',
                'default'  => '',
            ),
            array(
                'id'       => 'delivery_boy_apps_firebase_sender_id',
                'type'     => 'text',
                'placeholder' => '575406529046',
                'title'    => 'Firebase sender id',
                'subtitle' => 'Enter Firebase sender id',
                'default'  => '575406529046',
            ),
        )
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Delivery Boy Push Settings', 'mstoreapp-admin' ),
        'id'         => 'apps_delivery_boy_push_settings',
        'subsection' => true,
        'icon'  => 'el el-cog',
        'fields'     => array(
            array(
                'id'       => 'delivery_boy_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'All Notifications', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable all notifications for delivery boy apps', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'delivery_boy_new_order_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'New order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for new order', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'delivery_boy_assign_order_push',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Assign order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to enable/disable notifications for assigned order', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Delivery Boy New Order Message', 'mstoreapp-admin' ),
        'id'         => 'apps_delivery_boy_push_text',
        'subsection' => true,
        'icon'  => 'el el-envelope',
        'fields'     => array(
            array(
                'id'       => 'new_order_delivery_boy_title',
                'type'     => 'text',
                'title'    => 'Order Title',
                'subtitle' => 'New order push notification title. #id will be replaced by order id',
                'validate' => 'text',
                'default'  => '#id New order',
            ),
            array(
                'id'       => 'new_order_delivery_boy_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Order Message',
                'subtitle' => 'New order push notification message. #id will be replaced by order id. #pm replaced by payment method',
                'validate' => 'text',
                'default'  => 'You have received a new order of Total #total, Order id #id, Payment method #pm',
            ),

            array(
                'id'       => 'new_order_assign_delivery_boy',
                'type'     => 'section',
                'title'    => __( 'Delivery Boy Assign Order Message', 'mstoreapp-admin' ),
                'subtitle' => __( 'Send notification message when mew order assigned to delivery boy', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),

            array(
                'id'       => 'new_order_assign_delivery_boy_title',
                'type'     => 'text',
                'title'    => 'Order Title',
                'subtitle' => 'Assign order push notification title. #id will be replaced by order id',
                'validate' => 'text',
                'default'  => '#id Assigned',
            ),
            array(
                'id'       => 'new_order_assign_delivery_boy_message',
                'type'     => 'textarea',
                'rows'     => 3,
                'title'    => 'Order Message',
                'subtitle' => 'Assign order push notification message. #id will be replaced by order id. #total will be replaced by order total',
                'validate' => 'text',
                'default'  => 'Order #id, is assigned to you, Total amount #total',
            )
        )
    ) );

    /*Redux::setSection( $opt_name, array(
        'title'      => __( 'Delivery Boy Permissions', 'mstoreapp-admin' ),
        'id'         => 'apps_delivery_boy_permissions',
        'subsection' => true,
        'icon'  => 'el el-key',
        'fields'     => array(
            array(
                'id'       => 'delivery_boy_role_to_access_app',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Delivery Boy roles to access app', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select delivery boy roles to get access to the app', 'mstoreapp-admin' ),
                'default'  => array( 'shop_manager' )
            ),
            array(
                'id'       => 'delivery_boy-read-permission',
                'type'     => 'section',
                'title'    => __( 'Read Only Permission', 'mstoreapp-admin' ),
                'subtitle' => __( 'With this roles delivery boy can get read permissions. These users can view orders', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),
            array(
                'id'       => 'delivery_boy_role_to_read_orders',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Venor roles to access orders', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select delivery boy roles to get access to the view orders', 'mstoreapp-admin' ),
                'default'  => array( 'shop_manager' )
            ),
            array(
                'id'       => 'delivery_boy_read_order_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'View order fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order fields delivery boy can view', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order fields delivery boy can view.', 'mstoreapp-admin' ),
                'options'  => array(
                    'number' => 'Order Number',
                    'status' => 'Order Status',
                    'date_created' => 'Order Date',
                    'line_items' => 'Line Items',
                    'billing' => 'Billing Address',
                    'shipping' => 'Shipping Address',
                    'payment_method' => 'Payment Method',
                    'shipping_lines' => 'Shipping Method',
                    'totals' => 'Totals'),
                'default'  => array( 'number', 'status', 'date_created', 'line_items', 'billing', 'shipping', 'payment_method', 'shipping_lines', 'totals' )
            ),
            array(
                'id'       => 'delivery_boy_filter_order_fields',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Filter order fields', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order fields delivery_boy can filter', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow you to control order fields delivery_boy can filter.', 'mstoreapp-admin' ),
                'options'  => array(
                    'after' => 'Date After',
                    'before' => 'Date Before',
                    'status' => 'Status',
                    'order' => 'Order',),
                'default'  => array( 'after', 'before', 'status', 'order' )
            ),


            array(
                'id'       => 'delivery_boy_write_permission',
                'type'     => 'section',
                'title'    => __( 'Read/Write Permission', 'mstoreapp-admin' ),
                'subtitle' => __( 'With this roles delivery boy can get both read and write permissions. These users can edit and create orders', 'mstoreapp-admin' ),
                'indent'   => true, // Indent all options below until the next 'section' option is set.
            ),
            array(
                'id'       => 'delivery_boy_role_to_write_orders',
                'type'     => 'select',
                'multi'    => true,
                'data'     => 'roles',
                'title'    => __( 'Delivery boy roles to write orders', 'mstoreapp-admin' ),
                'subtitle' => __( 'Select delivery boy roles to get access to the write orders', 'mstoreapp-admin' ),
                'default'  => array( 'shop_manager' )
            ),
            array(
                'id'       => 'delivery_boy_write_order_status',
                'type'     => 'select',
                'multi'    => true,
                'title'    => __( 'Change order status', 'mstoreapp-admin' ), 
                'subtitle' => __( 'Order Status delivery_boy can change', 'mstoreapp-admin' ),
                'desc'     => __( 'This will allow to control order status delivery_boy can change.', 'mstoreapp-admin' ),
                'options'  => array(
                    'pending' => 'Pending',
                    'processing' => 'Processing',
                    'on-hold' => 'On Hold',
                    'completed' => 'Completed',
                    'ready-delivery' => 'Ready For Delivery',
                    'cancelled' => 'Cancelled',
                    'refunded' => 'Refunded',
                    'failed' => 'Failed',
                    'trash' => 'Trash'),
                'default'  => array( 'pending', 'processing', 'completed' )
            ),
        )
    ) );*/

    //Settings
    Redux::setSection( $opt_name, array(
        'title' => __( 'Settings', 'mstoreapp-admin' ),
        'id'    => 'mstoreapp_admin_settings',
        'desc'  => __( 'Settings', 'mstoreapp-admin' ),
        'icon'  => 'el el-website'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Settings', 'mstoreapp-admin' ),
        'id'         => 'apps_settings',
        'subsection' => true,
        'icon'  => 'el el-key',
        'fields'     => array(
            array(
                'id'       => 'apps_google_map_api_key',
                'type'     => 'text',
                'title'    => 'Google Map Api Key',
                'subtitle' => 'Enter Google map api keys',
                'placeholder' => 'AIzadsfdsNFV_t5uk4dsafjK2h6w',
            ),
            array(
                'id'       => 'contact_number',
                'type'     => 'text',
                'title'    => 'Admin contact number',
                'subtitle' => 'Enter Admin contact number',
                'placeholder' => '+95012345678',
            ),
            array(
                'id'       => 'enable_vendor_chat',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Assign order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to whatsapp chat with vendor', 'mstoreapp-admin' ),
                'default'  => true,
            ),
            array(
                'id'       => 'enable_delivery_boy_chat',
                'type'     => 'switch',
                'on'       => 'Enabled',
                'off'      => 'Disabled',
                'title'    => __( 'Assign order', 'mstoreapp-admin' ),
                'subtitle' => __( 'This will allow you to whatsapp chat with delivery boy', 'mstoreapp-admin' ),
                'default'  => true,
            ),
        )
    ) );

    if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => __( 'Documentation', 'mstoreapp-admin' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */

    // If Redux is running as a plugin, this will remove the demo notice and links
    //add_action( 'redux/loaded', 'remove_demo' );

    // Function to test the compiler hook and demo CSS output.
    // Above 15 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
    //add_filter('redux/options/' . $opt_name . '/compiler', 'compiler_action', 15, 3);

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Change the default value of a field after it's been set, but before it's been useds
    //add_filter('redux/options/' . $opt_name . '/defaults', 'change_defaults' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'mstoreapp-admin' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'mstoreapp-admin' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the admin-apps plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'notices', array( ReduxFrameworkPlugin::instance(), 'notices' ) );
            }
        }
    }

