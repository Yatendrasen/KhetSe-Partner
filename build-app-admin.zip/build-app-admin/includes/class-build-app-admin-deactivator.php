<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://buildapp.online
 * @since      1.0.0
 *
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 * @author     Abdul Hakeem <info@buildapp.online>
 */
class Build_App_Admin_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		global $wpdb;

        // Drop Tables
        $wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . "dotapp_admin_notification" );

        remove_role('delivery_boy');

	}

}
