<?php

/**
 * Fired during plugin activation
 *
 * @link       https://buildapp.online
 * @since      1.0.0
 *
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 * @author     Abdul Hakeem <info@buildapp.online>
 */
class Build_App_Admin_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		//***** Installer *****
		global $wpdb;
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');	

		$charset_collate = '';
		if (!empty($wpdb->charset)){
		    $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}else{
		    $charset_collate = "DEFAULT CHARSET=utf8";
		}
		if (!empty($wpdb->collate)){
		    $charset_collate .= " COLLATE $wpdb->collate";
		}

		$table_name = $wpdb->prefix . "dotapp_admin_notification";
		        
		$lk_tbl_sql = "CREATE TABLE " . $table_name . " (
		        ID bigint(20) unsigned NOT NULL auto_increment,
		        push_token varchar(162) NOT NULL default '',
		        user_id varchar(162) NOT NULL UNIQUE,
		        wp_user_id int(8) NOT NULL default 0,
		        user_role varchar(162) NOT NULL default '',
		        platform varchar(10) NOT NULL default '',
		        new_order TINYINT NOT NULL default 1,
		        new_customer TINYINT NOT NULL default 1,
		        low_stock TINYINT NOT NULL default 1,
		        new_comment TINYINT NOT NULL default 0,
		        new_note TINYINT NOT NULL default 0,
		        order_cancelled TINYINT NOT NULL default 0,
		        order_failed TINYINT NOT NULL default 0,
		        order_pending TINYINT NOT NULL default 0,
		        payment_failed TINYINT NOT NULL default 0,
		        status varchar(20) NOT NULL default '',
		        PRIMARY KEY (ID)
		      )" . $charset_collate . ";";
		dbDelta($lk_tbl_sql);

		add_role( 'delivery_boy', 'Delivery Boy' );

	}

}
