<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://buildapp.online
 * @since      1.0.0
 *
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Build_App_Admin
 * @subpackage Build_App_Admin/includes
 * @author     Abdul Hakeem <info@buildapp.online>
 */
class Build_App_Admin {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Build_App_Admin_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'BUILD_APP_ADMIN_VERSION' ) ) {
			$this->version = BUILD_APP_ADMIN_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'build-app-admin';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Build_App_Admin_Loader. Orchestrates the hooks of the plugin.
	 * - Build_App_Admin_i18n. Defines internationalization functionality.
	 * - Build_App_Admin_Admin. Defines all hooks for the admin area.
	 * - Build_App_Admin_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-build-app-admin-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-build-app-admin-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-build-app-admin-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-build-app-admin-public.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/admin-init.php';

		$this->loader = new Build_App_Admin_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Build_App_Admin_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Build_App_Admin_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Build_App_Admin_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$this->loader->add_action( 'init', $plugin_admin, 'handle_orgin' );

		$this->loader->add_action( 'save_post_product', $plugin_admin, 'save_new_product', 10, 3  );

		$this->loader->add_filter('woocommerce_rest_product_object_query', $plugin_admin, 'mstoreapp_prepare_product_query', 10, 2);

		$this->loader->add_filter('woocommerce_rest_prepare_shop_order_object', $plugin_admin, 'prepare_order_object', 501, 3);

		$this->loader->add_filter('woocommerce_rest_shop_order_object_query', $plugin_admin, 'mstoreapp_prepare_order_query', 10, 2);

		//$this->loader->add_filter('pre_get_posts', $plugin_admin, 'mstoreapp_filter_orders', 10, 2);
		$this->loader->add_filter('pre_get_posts', $plugin_admin, 'mstoreapp_filter_post', 10, 2);
		$this->loader->add_action( 'pre_user_query', $plugin_admin, 'geo_location_user_query', 100, 1  );

		$this->loader->add_action( 'added_post_meta', $plugin_admin, 'added_post_meta', 10, 4  );

		$this->loader->add_action('wp_ajax_build-app-online-admin_subcribe_notification', $plugin_admin, 'admin_subcribe_notification');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_subcribe_notification', $plugin_admin, 'admin_subcribe_notification');

        $this->loader->add_action('wp_ajax_build-app-online-admin_get_subcribe_notification', $plugin_admin, 'admin_get_subcribe_notification');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_get_subcribe_notification', $plugin_admin, 'admin_get_subcribe_notification');

        $this->loader->add_action('wp_ajax_build-app-online-admin_assign_delivery_boy', $plugin_admin, 'assign_delivery_boy');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_assign_delivery_boy', $plugin_admin, 'assign_delivery_boy');

        $this->loader->add_action('wp_ajax_build-app-online-admin_upload_image', $plugin_admin, 'upload_image');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_upload_image', $plugin_admin, 'upload_image');

        $this->loader->add_action('wp_ajax_build-app-online-admin_test', $plugin_admin, 'admin_test');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_test', $plugin_admin, 'admin_test');

        $this->loader->add_action('woocommerce_checkout_create_order', $plugin_admin, 'before_checkout_create_order', 20, 2);

        $this->loader->add_action( 'woocommerce_new_order', $plugin_admin, 'admin_new_order',  10, 1  );

        $this->loader->add_filter( 'woocommerce_thankyou_order_received_text', $plugin_admin, 'send_new_order_push_notification', 199, 2 );

        $this->loader->add_action( 'woocommerce_created_customer', $plugin_admin, 'admin_new_customer', 10, 3 );

        $this->loader->add_action( 'comment_post', $plugin_admin, 'admin_new_comment', 10, 2 );
          
        $this->loader->add_action( 'woocommerce_low_stock', $plugin_admin, 'admin_low_stock', 10, 1 );

        $this->loader->add_action('wp_ajax_build-app-online-admin_bookings', $plugin_admin, 'get_admin_bookings');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_bookings', $plugin_admin, 'get_admin_bookings');

        $this->loader->add_action('wp_ajax_build-app-online-update_booking', $plugin_admin, 'update_booking');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-update_booking', $plugin_admin, 'update_booking');

        $this->loader->add_action('wp_ajax_build-app-online-admin_site_online', $plugin_admin, 'site_online');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_site_online', $plugin_admin, 'site_online');

		//$this->loader->add_action('wp_ajax_build-app-online-admin_upload_image', $plugin_admin, 'upload_image');
        //$this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_upload_image', $plugin_admin, 'upload_image');

        $this->loader->add_action('wp_ajax_build-app-online-admin_order_action', $plugin_admin, 'order_action');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_order_action', $plugin_admin, 'order_action');

        $this->loader->add_action('wp_ajax_build-app-online-admin-notifications', $plugin_admin, 'admin_notifications');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin-notifications', $plugin_admin, 'admin_notifications');

        $this->loader->add_action('woocommerce_order_status_changed', $plugin_admin, 'order_status_changed', 10, 1  );

        $this->loader->add_action('wp_ajax_build-app-online-admin-jwt_token', $plugin_admin, 'firebase_jwt_token');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin-jwt_token', $plugin_admin, 'firebase_jwt_token');

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Build_App_Admin_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		$this->loader->add_action('wp_ajax_build-app-online-admin_options', $plugin_public, 'admin_options');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_options', $plugin_public, 'admin_options');

        $this->loader->add_action('wp_ajax_build-app-online-admin_login', $plugin_public, 'admin_login');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_login', $plugin_public, 'admin_login');

        $this->loader->add_action('wp_ajax_build-app-online-admin_logout', $plugin_public, 'admin_logout');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_logout', $plugin_public, 'admin_logout');

        $this->loader->add_action('wp_ajax_build-app-online-admin_vendor_order_list', $plugin_public, 'vendor_order_list');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_vendor_order_list', $plugin_public, 'vendor_order_list');

        $this->loader->add_action('wp_ajax_build-app-online-admin_set_fulfill_status', $plugin_public, 'set_fulfill_status');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_set_fulfill_status', $plugin_public, 'set_fulfill_status');

        $this->loader->add_action('wp_ajax_build-app-online-admin_update_location', $plugin_public, 'update_location');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_update_location', $plugin_public, 'update_location');

        $this->loader->add_action('wp_ajax_build-app-online-admin_get_delivery_info', $plugin_public, 'get_delivery_info');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_get_delivery_info', $plugin_public, 'get_delivery_info');

        $this->loader->add_action('wp_ajax_build-app-online-admin_google_login', $plugin_public, 'google_login');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_google_login', $plugin_public, 'google_login');

        $this->loader->add_action('wp_ajax_build-app-online-admin_get_brands', $plugin_public, 'get_brands');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_get_brands', $plugin_public, 'get_brands');

        $this->loader->add_action('wp_ajax_build-app-online-admin_upload_image', $plugin_public, 'uploadimage');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_upload_image', $plugin_public, 'uploadimage');

        $this->loader->add_action('wp_ajax_build-app-online-admin_update_user_meta', $plugin_public, 'bao_update_user_meta');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin_update_user_meta', $plugin_public, 'bao_update_user_meta');

		$this->loader->add_action('wp_ajax_build-app-online-admin-fcm_details', $plugin_public, 'fcm_details');
        $this->loader->add_action('wp_ajax_nopriv_build-app-online-admin-fcm_details', $plugin_public, 'fcm_details');

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Build_App_Admin_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
